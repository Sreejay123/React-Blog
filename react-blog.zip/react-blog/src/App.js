import Routee from './components/Routee';
import React from 'react';
class App extends React.Component {
  render(){
  return (
       <Routee/>
  );
}
}
export default App;
